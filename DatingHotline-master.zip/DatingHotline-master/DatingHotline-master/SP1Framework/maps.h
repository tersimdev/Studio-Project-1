#pragma once
#include <fstream>
#include <string>

std::string chooseNextMap(int i = 0); //function to choose the next map
