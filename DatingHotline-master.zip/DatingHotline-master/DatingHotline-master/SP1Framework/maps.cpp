#include "maps.h"


std::string chooseNextMap(int i) 
{
	switch (i)
	{
	case 0:
		return "Levels/_Level01.txt";
		break;
	case 1:
		return "Levels/_Level01.txt";
		break;
	case 2:
		return "Levels/_Level01.txt";
		break;
	case 4:
		return "Levels/_Level01.txt";
		break;
	}
	i++;
} 